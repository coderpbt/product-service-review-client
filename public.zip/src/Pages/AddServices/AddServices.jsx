import React from 'react';

const AddServices = () => {
  return (
    <div>
      <p>Add Service</p>
    </div>
  );
};

export default AddServices;