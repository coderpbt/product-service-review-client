import React from 'react';

const Blog = () => {
  return (
    <div>
      <p>blog</p>
    </div>
  );
};

export default Blog;